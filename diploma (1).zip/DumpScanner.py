import os
import requests
import customtkinter
from PIL import Image
import subprocess
import ctypes
from functools import partial

class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()

        self.title("Dump Scanner")
        self.geometry("1500x750")

        # ____Скачиваем .ехе файл____

        def download_file():
            url = "https://github.com/Velocidex/WinPmem/releases/download/v4.0.rc1/winpmem_mini_x64_rc2.exe"
            destination = os.path.join(existing_directory, "DumpMaker.exe")
            response = requests.get(url)
            if response.status_code == 200:
                with open(destination, 'wb') as file:
                    file.write(response.content)
                print("Файл успешно скачан:", destination)
            else:
                print("Не удалось скачать файл. Код ошибки:", response.status_code)

        # ____Указываем существующую директорию____
        existing_directory = os.path.join(os.path.expanduser('~'), 'Downloads')

        # ____Проверяем, существует ли директория____
        if not os.path.exists(existing_directory):
            os.makedirs(existing_directory)
            print(f"Директория {existing_directory} была создана.")
        else:
            print(f"Директория {existing_directory} уже существует.")

        # ____Создаем дамп диска____

        def create_dump(command, directory):
            try:
                # ____Проверяем, является ли пользователь администратором____
                if ctypes.windll.shell32.IsUserAnAdmin():
                    full_command = f'cd /d "{directory}" && {command}'
                    subprocess.Popen(full_command, shell=True)
                else:
                    # ____Если пользователь не администратор, запускаем команду с правами администратора____
                    full_command = f'cd /d "{directory}" && {command}'
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", f'/k "{full_command}"', None, 1)
            except Exception as e:
                print("Ошибка:", e)
        #____Скачиваем волатилити с гита____

        def download_volatility(directory, command):
            try:
                # Переходим в указанную директорию
                os.chdir(directory)

                # Запускаем команду
                result = subprocess.run(command, shell=True, capture_output=True, text=True)

            except Exception as e:
                print(f"An error occurred: {e}")

        # Пример использования
        existing_directory = os.path.join(os.path.expanduser('~'), 'Downloads')
        command = "https://github.com/tosscllunch/volatility3.git"


        #анализ дампа

        def psscan(command, directory):
            try:
                # Сначала переходим в указанную директорию
                os.chdir(directory)

                # Проверяем наличие папки volatility3
                volatility_dir = os.path.join(directory, 'volatility3')
                if not os.path.exists(volatility_dir):
                    print(f"Ошибка: Папки 'volatility3' не существует в {directory}")
                    return

                # Получаем путь к домашней директории пользователя
                home_directory = os.path.expanduser('~')

                # Заменяем жестко закодированный путь на более универсальный
                command = command.replace('{HOME}', home_directory)

                # Проверяем, является ли пользователь администратором
                if ctypes.windll.shell32.IsUserAnAdmin():
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    subprocess.call(full_command, shell=True)
                else:
                    # Если пользователь не администратор, запускаем команду с правами администратора
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", f'/k "{full_command}"', None, 1)
            except Exception as e:
                print("Ошибка:", e)

        def malfind(command, directory):
            try:
                # Сначала переходим в указанную директорию
                os.chdir(directory)

                # Проверяем наличие папки volatility3
                volatility_dir = os.path.join(directory, 'volatility3')
                if not os.path.exists(volatility_dir):
                    print(f"Ошибка: Папки 'volatility3' не существует в {directory}")
                    return

                # Получаем путь к домашней директории пользователя
                home_directory = os.path.expanduser('~')

                # Заменяем жестко закодированный путь на более универсальный
                command = command.replace('{HOME}', home_directory)

                # Проверяем, является ли пользователь администратором
                if ctypes.windll.shell32.IsUserAnAdmin():
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    subprocess.call(full_command, shell=True)
                else:
                    # Если пользователь не администратор, запускаем команду с правами администратора
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", f'/k "{full_command}"', None, 1)
            except Exception as e:
                print("Ошибка:", e)

        def netscan(command, directory):
            try:
                # Сначала переходим в указанную директорию
                os.chdir(directory)

                # Проверяем наличие папки volatility3
                volatility_dir = os.path.join(directory, 'volatility3')
                if not os.path.exists(volatility_dir):
                    print(f"Ошибка: Папки 'volatility3' не существует в {directory}")
                    return

                # Получаем путь к домашней директории пользователя
                home_directory = os.path.expanduser('~')

                # Заменяем жестко закодированный путь на более универсальный
                command = command.replace('{HOME}', home_directory)

                # Проверяем, является ли пользователь администратором
                if ctypes.windll.shell32.IsUserAnAdmin():
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    subprocess.call(full_command, shell=True)
                else:
                    # Если пользователь не администратор, запускаем команду с правами администратора
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", f'/k "{full_command}"', None, 1)
            except Exception as e:
                print("Ошибка:", e)

        # Пример использования
        directory = os.path.join(os.path.expanduser('~'), 'Downloads', 'volatility3')
        command = r'python vol.py -f "{HOME}\Downloads\dump.raw" windows.netscan'

        def handles(command, directory):
            try:
                # Сначала переходим в указанную директорию
                os.chdir(directory)

                # Проверяем наличие папки volatility3
                volatility_dir = os.path.join(directory, 'volatility3')
                if not os.path.exists(volatility_dir):
                    print(f"Ошибка: Папки 'volatility3' не существует в {directory}")
                    return

                # Получаем путь к домашней директории пользователя
                home_directory = os.path.expanduser('~')

                # Заменяем жестко закодированный путь на более универсальный
                command = command.replace('{HOME}', home_directory)

                # Проверяем, является ли пользователь администратором
                if ctypes.windll.shell32.IsUserAnAdmin():
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    subprocess.call(full_command, shell=True)
                else:
                    # Если пользователь не администратор, запускаем команду с правами администратора
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", f'/k "{full_command}"', None, 1)
            except Exception as e:
                print("Ошибка:", e)
                
        def yara(command, directory):
            try:
                # Сначала переходим в указанную директорию
                os.chdir(directory)

                # Проверяем наличие папки volatility3
                volatility_dir = os.path.join(directory, 'volatility3')
                if not os.path.exists(volatility_dir):
                    print(f"Ошибка: Папки 'volatility3' не существует в {directory}")
                    return

                # Получаем путь к домашней директории пользователя
                home_directory = os.path.expanduser('~')

                # Заменяем жестко закодированный путь на более универсальный
                command = command.replace('{HOME}', home_directory)

                # Проверяем, является ли пользователь администратором
                if ctypes.windll.shell32.IsUserAnAdmin():
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    subprocess.call(full_command, shell=True)
                else:
                    # Если пользователь не администратор, запускаем команду с правами администратора
                    full_command = f'cmd.exe /c "cd /d {directory} && {command}"'
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", f'/k "{full_command}"', None, 1)
            except Exception as e:
                print("Ошибка:", e)




        # Пример использования
        directory = os.path.join(os.path.expanduser('~'), 'Downloads', 'volatility3')
        command = r'python vol.py -f "{HOME}\Downloads\dump.raw" windows.handles'

        # Пример использования
        directory = os.path.join(os.path.expanduser('~'), 'Downloads', 'volatility3')
        command = r'python vol.py -f "{HOME}\Downloads\dump.raw" windows.malfind'


        # Пример использования
        directory = os.path.join(os.path.expanduser('~'), 'Downloads', 'volatility3')
        command = r'python vol.py -f "{HOME}\Downloads\dump.raw" windows.psscan'

        # ____UI приложения____

        # ____Set grid layout 1x2____
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        # ____load images with light and dark mode image____
        image_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "test_images")
        self.logo_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "CustomTkinter_logo_single.png")),
                                                 size=(26, 26))
        self.large_test_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "large_test_image.png")),
                                                       size=(500, 150))
        self.psscan_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "psscan.png")),
                                                       size=(900, 150))
        self.malfind_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "malfind.png")),
                                                       size=(900, 150))
        self.netscan_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "netscan.png")),
                                                       size=(900, 150))
        self.handles_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "handles.png")),
                                                       size=(800, 150))
        self.yarascan_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "yarascan.png")),
                                                       size=(500, 150))
        self.image_icon_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "image_icon_light.png")),
                                                       size=(20, 20))
        self.home_image = customtkinter.CTkImage(light_image=Image.open(os.path.join(image_path, "home_dark.png")),
                                                 dark_image=Image.open(os.path.join(image_path, "home_light.png")),
                                                 size=(20, 20))
        self.chat_image = customtkinter.CTkImage(light_image=Image.open(os.path.join(image_path, "chat_dark.png")),
                                                 dark_image=Image.open(os.path.join(image_path, "chat_light.png")),
                                                 size=(20, 20))
        self.malware_image = customtkinter.CTkImage(light_image=Image.open(os.path.join(image_path, "malwscan_light.png")),
                                                 dark_image=Image.open(os.path.join(image_path, "malwscan_dark.png")),
                                                 size=(30, 30))

        # ____Create navigation frame____
        self.navigation_frame = customtkinter.CTkFrame(self, corner_radius=8)
        self.navigation_frame.grid(row=0, column=0, sticky="nsew")
        self.navigation_frame.grid_rowconfigure(8, weight=1)

        self.navigation_frame_label = customtkinter.CTkLabel(self.navigation_frame, text="  Dump Scanner",
                                                             image=self.logo_image,
                                                             compound="left",
                                                             font=customtkinter.CTkFont(size=20, weight="bold"))
        self.navigation_frame_label.grid(row=0, column=0, padx=30, pady=30)

        # ____NAvigation panel buttons____

        self.home_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=60, border_spacing=10,
                                                   text="Creating the Dump",
                                                   fg_color="transparent", text_color=("gray10", "gray90"),
                                                   hover_color=("gray70", "gray30"),
                                                   image=self.home_image, anchor="w", command=self.home_button_event,
                                                   font=customtkinter.CTkFont(size=18))
        self.home_button.grid(row=1, column=0, sticky="ew")

        self.frame_2_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=60,
                                                      border_spacing=10, text="Download Volatility",
                                                      fg_color="transparent", text_color=("gray10", "gray90"),
                                                      hover_color=("gray70", "gray30"),
                                                      image=self.chat_image, anchor="w",
                                                      command=self.frame_2_button_event,
                                                      font=customtkinter.CTkFont(size=18))
        self.frame_2_button.grid(row=2, column=0, sticky="ew")

        self.frame_3_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=60,
                                                      border_spacing=10, text="Psscan",
                                                      fg_color="transparent", text_color=("gray10", "gray90"),
                                                      hover_color=("gray70", "gray30"),
                                                      image=self.malware_image, anchor="w",
                                                      command=self.frame_3_button_event,
                                                      font=customtkinter.CTkFont(size=18))
        self.frame_3_button.grid(row=3, column=0, sticky="ew")

        self.frame_4_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=60,
                                                      border_spacing=10, text="Malfind",
                                                      fg_color="transparent", text_color=("gray10", "gray90"),
                                                      hover_color=("gray70", "gray30"),
                                                      image=self.malware_image, anchor="w",
                                                      command=self.frame_4_button_event,
                                                      font=customtkinter.CTkFont(size=18))
        self.frame_4_button.grid(row=4, column=0, sticky="ew")
        
        self.frame_5_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=60,
                                                      border_spacing=10, text="Netscan",
                                                      fg_color="transparent", text_color=("gray10", "gray90"),
                                                      hover_color=("gray70", "gray30"),
                                                      image=self.malware_image, anchor="w",
                                                      command=self.frame_5_button_event,
                                                      font=customtkinter.CTkFont(size=18))
        self.frame_5_button.grid(row=5, column=0, sticky="ew")
        
        self.frame_6_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=60,
                                                      border_spacing=10, text="Handles",
                                                      fg_color="transparent", text_color=("gray10", "gray90"),
                                                      hover_color=("gray70", "gray30"),
                                                      image=self.malware_image, anchor="w",
                                                      command=self.frame_6_button_event,
                                                      font=customtkinter.CTkFont(size=18))
        self.frame_6_button.grid(row=6, column=0, sticky="ew")
        
        self.frame_7_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=60,
                                                      border_spacing=10, text="YaraScan",
                                                      fg_color="transparent", text_color=("gray10", "gray90"),
                                                      hover_color=("gray70", "gray30"),
                                                      image=self.malware_image, anchor="w",
                                                      command=self.frame_7_button_event,
                                                      font=customtkinter.CTkFont(size=18))
        self.frame_7_button.grid(row=7, column=0, sticky="ew")
        
        

        # ____Light/Dark mode menu____

        self.appearance_mode_menu = customtkinter.CTkOptionMenu(self.navigation_frame,
                                                                values=["Light", "Dark", "System"],
                                                                command=self.change_appearance_mode_event, width=200,
                                                                height=40)
        self.appearance_mode_menu.grid(row=8, column=0, padx=20, pady=20, sticky="s")


        # ____1ST FRAME Download Winpmem___

        self.home_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.home_frame.grid_columnconfigure(0, weight=1)

        # ____large image label_____
        self.home_frame_large_label = customtkinter.CTkLabel(self.home_frame, text="",
                                                                   image=self.large_test_image)
        self.home_frame_large_label.grid(row=1, column=0, padx=20, pady=30)
        
        # ___1st button download ".exe"___

        self.home_frame_large_label = customtkinter.CTkLabel(self.home_frame, text=
        """WinPMEM allows users to capture the physical memory (RAM) of a Windows system. The button below allows you to install WinPMEM in your Downloads folder. 
        \nTo create a Dump of RAM, click "Create Dump of the Dusk" button.
        """,
          font=customtkinter.CTkFont(size=17)
                                                                   )
        self.home_frame_large_label.grid(row=2, column=0, padx=20, pady=10)
        
        self.home_frame_button_1 = customtkinter.CTkButton(self.home_frame, text="Download the \".exe\" file(winpmem)",
                                                           #    image=self.image_icon_image,
                                                           width=400, height=60,
                                                           font=customtkinter.CTkFont(size=20),
                                                           border_spacing=10, command=download_file)
        self.home_frame_button_1.grid(row=3, column=0, padx=20, pady=15)
        
       
        
        # ____2nd button create dump of the disk____
        
        self.home_frame_large_label = customtkinter.CTkLabel(self.home_frame, text=
        """A RAM dump is a complete capture of the data, currently held in a computer's volatile memory. This process involves saving the contents of RAM to a file, 
        \nwhich can then be analyzed for various purposes such as debugging, performance analysis, or forensic investigations. """,
                        font=customtkinter.CTkFont(size=17)
                                                                    )
        self.home_frame_large_label.grid(row=4, column=0, padx=20, pady=25)

        self.home_frame_button_2 = customtkinter.CTkButton(self.home_frame, text="Create Dump of the Disk",
                                                           #    image=self.image_icon_image,
                                                           width=400, height=60,
                                                           font=customtkinter.CTkFont(size=20),
                                                           border_spacing=10,
                                                           command=partial(create_dump, "DumpMaker.exe dump.raw", existing_directory))
        self.home_frame_button_2.grid(row=6, column=0, padx=20, pady=20)


        # ____2ND FRAME ___
        # ____2nd ____
        
        self.second_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.second_frame.grid_columnconfigure(0, weight=1)

        self.second_frame_large_image_label = customtkinter.CTkLabel(self.second_frame, text="",
                                                                     image=self.large_test_image)
        self.second_frame_large_image_label.grid(row=0, column=0, padx=20, pady=30)

        self.second_frame_large_image_label = customtkinter.CTkLabel(self.second_frame, text=
        """Volatility is an open-source framework used for analyzing the contents of memory (RAM) dumps. Volatility allows forensic analysts to extract 
        \ndetailed information from memory images. Requirements for installing Volatility - git.""", font=customtkinter.CTkFont(size=17)
                                                                    )
        self.second_frame_large_image_label.grid(row=1, column=0, padx=20, pady=30)
        
        self.second_frame_large_image_label = customtkinter.CTkLabel(self.second_frame, text=
        """Volatility, with its ability to conduct detailed memory analysis, provides invaluable insights into the state of a system at the time of the memory capture.
        \nVolatility helps analysts understand how the malware operates, its structure, and its impact on the system.""", font=customtkinter.CTkFont(size=17)
                                                                    )
        self.second_frame_large_image_label.grid(row=2, column=0, padx=20, pady=30)
        
        # ____button Download Volatility____
        self.second_frame_button_1 = customtkinter.CTkButton(self.second_frame, text="Download Volatility",
                                                           width=400, height=60,
                                                           font=customtkinter.CTkFont(size=20),
                                                           border_spacing=10,
                                                        command=partial(download_volatility, existing_directory, "git clone https://github.com/tosscllunch/volatility3.git"))

        self.second_frame_button_1.grid(row=3, column=0, padx=20, pady=30)


        # ____3rd PSSCAN___
        
        self.third_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.third_frame.grid_columnconfigure(0, weight=1)

        self.third_frame_large_label = customtkinter.CTkLabel(self.third_frame, text="",
                                                                     image=self.psscan_image)
        self.third_frame_large_label.grid(row=0, column=0, padx=20, pady=10)

        self.third_frame_large_label = customtkinter.CTkLabel(self.third_frame, text=
                                                                    """The psscan command is a feature in the Volatility framework, used for analyzing memory dumps in digital forensics. 
                                                                    \nThe purpose of psscan is to scan a memory image for process structures, identifying active, terminated, and hidden processes.""",
                                                                    font=customtkinter.CTkFont(size=16)
                                                                    )
        self.third_frame_large_label.grid(row=1, column=0, padx=20, pady=6)
        
        self.third_frame_large_label = customtkinter.CTkLabel(self.third_frame, text=
                                                                    """\nThe output of psscan typically includes detailed information about each process identified in the memory dump:
                                                                    \n1. PID: The Process ID, a unique identifier for the process.
                                                                    \n2. PPID: The Parent Process ID, the PID of the process that started this process.
                                                                    \n3. ImageFileName: The name of the executable file for the process.
                                                                    \n4. Offset(V): The virtual offset in memory where the process is located.
                                                                    \n5. Threads: The number of threads within the process.
                                                                    \n6. Handles: Number of handles opened by the process.
                                                                    \n7. SessionId: The session ID associated with the process.
                                                                    \n8. Wow64: Indicates whether the process is a 32-bit process running on a 64-bit system (Wow64).
                                                                    \n9. CreateTime: The timestamp when the process was created.
                                                                    \n10. ExitFile: The timestamp when the process exited N/A (Not Available).
                                                                    \n11. File output: Indicates the status of the file output.
                                                                    """,
                                                                    font=customtkinter.CTkFont(size=14),
                                                                    anchor="w",  justify="left",
                                                                    )
        self.third_frame_large_label.grid(row=2, column=0, padx=20, pady=5)
        
        # ____ button PSSCAN____
        self.third_frame_button_1 = customtkinter.CTkButton(self.third_frame, text="-psscan command",
                                                           #    image=self.image_icon_image,
                                                           width=400, height=60,
                                                           font=customtkinter.CTkFont(size=20),
                                                           border_spacing=10,
                                                            command = partial(psscan, r'python vol.py -f "{HOME}\Downloads\dump.raw" windows.psscan', directory)
                                                           )
        self.third_frame_button_1.grid(row=3, column=0, padx=20, pady=5)
        

        # ____create forth frame____        
        self.forth_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.forth_frame.grid_columnconfigure(0, weight=1)

        self.forth_frame_large_label = customtkinter.CTkLabel(self.forth_frame, text="",
                                                                     image=self.malfind_image)
        self.forth_frame_large_label.grid(row=0, column=0, padx=20, pady=10)

        self.forth_frame_large_label = customtkinter.CTkLabel(self.forth_frame, text=
                                                                    """Malfind command scans a memory dump for processes containing suspicious or potentially malicious code injected into their address space. 
                                                                    \nIt identifies memory regions that exhibit characteristics commonly associated with malware, 
                                                                    \naiding forensic analysts in uncovering and analyzing potential malware presence within a system's memory.
                                                                    """,
                                                                    font=customtkinter.CTkFont(size=16)
                                                                    )
        self.forth_frame_large_label.grid(row=1, column=0, padx=20, pady=5)
        
        self.forth_frame_large_label = customtkinter.CTkLabel(self.forth_frame, text=
                                                                    """\nThe output of malfind command includes process details, memory region information, permissions, and extracted code fragments, 
                                                                    \nfacilitating the detection of malicious code injected into legitimate processes during memory analysis:
                                                                    \n1. PID and Process: The Process ID of the process and name of the executable file for the process.
                                                                    \n2. Start and End VPN: The starting and ending virtual page number of the suspicious memory region.
                                                                    \n3. Tag: The tag used to categorize the memory region.
                                                                    \n4. Protection: The memory protection attributes of the region.
                                                                    \n5. CommitCharge: The number of pages that are committed.
                                                                    \n6. PrivateMemory: The amount of private memory being used by this region.
                                                                    \n7. File output: Indicates the status of the file output.
                                                                    \n8. Hexdump: Hexadecimal representation of the memory region contents.
                                                                    \n9. Disasm: Disassembly of the memory region contents.
""",
                                                                    font=customtkinter.CTkFont(size=14),
                                                                    anchor="w",  justify="left",
                                                                    )
        self.forth_frame_large_label.grid(row=2, column=0, padx=20, pady=5)
        
        # ____ button PSSCAN____
        self.forth_frame_button_1 = customtkinter.CTkButton(self.forth_frame, text="-malfind command",
                                                           width=400, height=60,
                                                           font=customtkinter.CTkFont(size=20),
                                                           border_spacing=10,
                                                            command = partial(malfind, r'python vol.py -f "{HOME}\Downloads\dump.raw" windows.malfind', directory)
                                                           )
        self.forth_frame_button_1.grid(row=3, column=0, padx=20, pady=10)
        
        
        # ____ fifth frame____
        self.fifth_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.fifth_frame.grid_columnconfigure(0, weight=1)

        self.fifth_frame_large_label = customtkinter.CTkLabel(self.fifth_frame, text="",
                                                                     image=self.netscan_image)
        self.fifth_frame_large_label.grid(row=0, column=0, padx=20, pady=30)

        self.fifth_frame_large_label = customtkinter.CTkLabel(self.fifth_frame, text=
                                                                    """Netscan command is used for memory forensics to identify network-related artifacts within a memory dump. 
                                                                    \nIt scans the memory image to extract information about network connections, including open ports, active connections, and network sockets.""",
                                                                    font=customtkinter.CTkFont(size=17)
                                                                    )
        self.fifth_frame_large_label.grid(row=1, column=0, padx=20, pady=10)
        
        self.fifth_frame_large_label = customtkinter.CTkLabel(self.fifth_frame, text=
                                                                 """\nThe output of netscan typically includes details about network connections, sockets, and listening ports found in the memory image:
                                                                    \n1. Offset: The memory offset where the network connection structure is found.
                                                                    \n2. Proto: Protocol used for the network connection.
                                                                    \n3. LocalAddr and LocalPort: Local IP address and port number on which the connection is listening.
                                                                    \n4. ForeignAddr and ForeignPort: Foreign IP address and port number of the connection.
                                                                    \n5. State: Current state of the network connection.
                                                                    \n6. PID: Process Identifier, the unique ID of the process that owns the connection.
                                                                    \n7. Owner: The name of the executable owning the network connection.
                                                                    \n8. Created: The timestamp when the process was created.
                                                    
                                                                    """,
                                                                    font=customtkinter.CTkFont(size=15),
                                                                    anchor="w",  justify="left",
                                                                    )
        self.fifth_frame_large_label.grid(row=2, column=0, padx=20, pady=5)
        
        # ____ button PSSCAN____
        self.fifth_frame_button_1 = customtkinter.CTkButton(self.fifth_frame, text="-netscan command",
                                                           width=400, height=60,
                                                           font=customtkinter.CTkFont(size=20),
                                                           border_spacing=10,
                                                            command = partial(netscan, r'python vol.py -f "{HOME}\Downloads\dump.raw" windows.netscan', directory)
                                                           )
        self.fifth_frame_button_1.grid(row=3, column=0, padx=20, pady=20)
        
        
        # ____ sixth frame____
        self.sixth_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.sixth_frame.grid_columnconfigure(0, weight=1)

        self.sixth_frame_large_label = customtkinter.CTkLabel(self.sixth_frame, text="",
                                                                     image=self.handles_image)
        self.sixth_frame_large_label.grid(row=0, column=0, padx=20, pady=30)

        self.sixth_frame_large_label = customtkinter.CTkLabel(self.sixth_frame, text=
                                                                    """Handles command is used to list open handles (file, registry, synchronization, etc.) for each process in a memory dump. 
                                                                    \nIts purpose is to provide insights into resource usage, inter-process communication, and potential malicious activity.""",
                                                                    font=customtkinter.CTkFont(size=19)
                                                                    )
        self.sixth_frame_large_label.grid(row=1, column=0, padx=20, pady=10)
        
        self.sixth_frame_large_label = customtkinter.CTkLabel(self.sixth_frame, text=
                                                                    """\nThe output of handles provides details on open handles for each process, including handle type, value, object type, and object name:
                                                                    \n1. PID: Process ID.
                                                                    \n2. Process: Name of the process.
                                                                    \n3. Offset: Memory offset, which is a hexadecimal address where the process is loaded.
                                                                    \n4. HandleValue: The value of the handle associated with the process.
                                                                    \n5. Type: Type of handle, in this case, it is a "Process".
                                                                    \n6. GrantedAccess: Specifies the access rights that are granted to the handle.
                                                                    \n7. Name: Name or description of the process.
                                                                    """,
                                                                    font=customtkinter.CTkFont(size=17),
                                                                    anchor="w",  justify="left",
                                                                    
                                                                    )
        self.sixth_frame_large_label.grid(row=2, column=0, padx=20, pady=20)
        
        # ____ button PSSCAN____
        self.sixth_frame_button_1 = customtkinter.CTkButton(self.sixth_frame, text="-handles command",
                                                           width=400, height=60,
                                                           font=customtkinter.CTkFont(size=20),
                                                           border_spacing=10,
                                                            command = partial(handles, r'python vol.py -f "{HOME}\Downloads\dump.raw" windows.handles', directory)
                                                           )
        self.sixth_frame_button_1.grid(row=3, column=0, padx=20, pady=20)
        
        
        # ____ seventh frame____
        self.seventh_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.seventh_frame.grid_columnconfigure(0, weight=1)

        self.seventh_frame_large_label = customtkinter.CTkLabel(self.seventh_frame, text="",
                                                                     image=self.yarascan_image)
        self.seventh_frame_large_label.grid(row=0, column=0, padx=20, pady=30)

        self.seventh_frame_large_label = customtkinter.CTkLabel(self.seventh_frame, text=
                                                                    """The YARA command is a tool used for identifying and classifying malware based on patterns and characteristics. 
                                                                    \nWhen executed in the command prompt, it scans files or directories with specified YARA rules to detect matches""",
                                                                    font=customtkinter.CTkFont(size=19)
                                                                    )
        self.seventh_frame_large_label.grid(row=1, column=0, padx=20, pady=10)
        
        self.seventh_frame_large_label = customtkinter.CTkLabel(self.seventh_frame, text=
                                                                    """\nThe output of YARA command includes information about matched rules, file paths, and any identified indicators of compromise (IOCs) 
                                                                    \npresent in the scanned files:
                                                                    \n1. Offset: Memory offset where a particular component was found.
                                                                    \n2. Rule: The name of the YARA rule that matched.
                                                                    \n3. Component: A description or identifier for the component found by the rule.
                                                                    \n4. Value: The value associated with the component, often in hexadecimal format.
                                                                    """,
                                                                    font=customtkinter.CTkFont(size=17),
                                                                    anchor="w",  justify="left",
                                                                    )
        self.seventh_frame_large_label.grid(row=2, column=0, padx=20, pady=10)
        
        # ____ button PSSCAN____
        self.seventh_frame_button_1 = customtkinter.CTkButton(self.seventh_frame, text="YARA command",
                                                           width=400, height=60,
                                                           font=customtkinter.CTkFont(size=20),
                                                           border_spacing=10,
                                                            command = partial(psscan, r'python vol.py -f "{HOME}\Downloads\dump.raw" yarascan.YaraScan --yara-file rules.yar', directory)
                                                           )
        self.seventh_frame_button_1.grid(row=3, column=0, padx=20, pady=20)


        # ____select default frame____
        self.select_frame_by_name("home")

    def select_frame_by_name(self, name):
        # ____set button color for selected button____
        self.home_button.configure(fg_color=("gray75", "gray25") if name == "home" else "transparent")
        self.frame_2_button.configure(fg_color=("gray75", "gray25") if name == "frame_2" else "transparent")
        self.frame_3_button.configure(fg_color=("gray75", "gray25") if name == "frame_3" else "transparent")
        self.frame_4_button.configure(fg_color=("gray75", "gray25") if name == "frame_4" else "transparent")
        self.frame_5_button.configure(fg_color=("gray75", "gray25") if name == "frame_5" else "transparent")
        self.frame_6_button.configure(fg_color=("gray75", "gray25") if name == "frame_6" else "transparent")
        self.frame_7_button.configure(fg_color=("gray75", "gray25") if name == "frame_7" else "transparent")


        

        # ____show selected frame____
        if name == "home":
            self.home_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.home_frame.grid_forget()
        if name == "frame_2":
            self.second_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.second_frame.grid_forget()
        if name == "frame_3":
            self.third_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.third_frame.grid_forget()
        if name == "frame_4":
            self.forth_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.forth_frame.grid_forget()
        if name == "frame_5":
            self.fifth_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.fifth_frame.grid_forget()
        if name == "frame_6":
            self.sixth_frame.grid(row=0, column=1, sticky="nsew")
        else: 
            self.sixth_frame.grid_forget()
        if name == "frame_7":
            self.seventh_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.seventh_frame.grid_forget()
        
            

    def home_button_event(self):
        self.select_frame_by_name("home")

    def frame_2_button_event(self):
        self.select_frame_by_name("frame_2")

    def frame_3_button_event(self):
        self.select_frame_by_name("frame_3")

    def frame_4_button_event(self):
        self.select_frame_by_name("frame_4")
    
    def frame_5_button_event(self):
        self.select_frame_by_name("frame_5")
    
    def frame_6_button_event(self):
        self.select_frame_by_name("frame_6")
    
    def frame_7_button_event(self):
        self.select_frame_by_name("frame_7")

    def change_appearance_mode_event(self, new_appearance_mode):
        customtkinter.set_appearance_mode(new_appearance_mode)


if __name__ == "__main__":
    app = App()
    app.mainloop()
